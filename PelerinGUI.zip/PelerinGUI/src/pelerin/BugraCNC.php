<?php

namespace pelerin;

use pocketmine\entity\Skin;
use pocketmine\event\player\{PlayerJoinEvent, PlayerQuitEvent, PlayerChangeSkinEvent};
use pocketmine\event\Listener;
use pocketmine\{Player, Server};
use pocketmine\plugin\PluginBase;
use pocketmine\command\Command;
use pocketmine\event\entity\EntitySpawnEvent;
use pocketmine\command\CommandSender;
use pocketmine\network\mcpe\protocol\DataPacket;
use pocketmine\entity\Entity;
use pocketmine\network\mcpe\protocol\AddActorPacket;
use pocketmine\network\mcpe\protocol\AddPlayerPacket;
use pocketmine\network\mcpe\protocol\MobEquipmentPacket;
use pocketmine\network\mcpe\protocol\PlayerListPacket;
use pocketmine\network\mcpe\protocol\types\PlayerListEntry;
use pocketmine\math\Vector3;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\utils\Config;
use pocketmine\nbt\tag\StringTag;
use pocketmine\item\Item;
use korado531m7\InventoryMenuAPI\InventoryMenu;
use korado531m7\InventoryMenuAPI\event\InventoryClickEvent;
use korado531m7\InventoryMenuAPI\event\InventoryCloseEvent;
use korado531m7\InventoryMenuAPI\inventory\HopperInventory;
use korado531m7\InventoryMenuAPI\inventory\ChestInventory;
use korado531m7\InventoryMenuAPI\InventoryType;

class BugraCNC extends PluginBase implements Listener{
	
	protected $skin = [];
	public $skins;
	
	public function onEnable(){
		$this->saveResource("capes.yml");
		$this->cfg = new Config($this->getDataFolder() . "capes.yml", Config::YAML);
		foreach($this->cfg->get("capes") as $cape){
			$this->saveResource("$cape.png");
		}
		$this->getLogger()->info("Cape System Enable.");
		$this->getServer()->getPluginManager()->registerEvents($this, $this);
		InventoryMenu::register($this);
	}
	
	public function onJoin(PlayerJoinEvent $e){
		$player = $e->getPlayer();
		$this->skin[$player->getName()] = $player->getSkin();
	}

	public function onQuit(PlayerQuitEvent $e){
		$player = $e->getPlayer();
		unset($this->skin[$player->getName()]);
	}

	public function onChangeSkin(PlayerChangeSkinEvent $e){
		$player = $e->getPlayer();
		$this->skin[$player->getName()] = $player->getSkin();
	}
	
	public function olusturPelerin($capeName){
		$path = $this->getDataFolder()."{$capeName}.png";
		$img = @imagecreatefrompng($path);
		$bytes = '';
		$l = (int) @getimagesize($path)[1];
		for($y = 0; $y < $l; $y++){
			for($x = 0; $x < 64; $x++){
				$rgba = @imagecolorat($img, $x, $y);
				$a = ((~((int)($rgba >> 24))) << 1) & 0xff;
				$r = ($rgba >> 16) & 0xff;
				$g = ($rgba >> 8) & 0xff;
				$b = $rgba & 0xff;
				$bytes .= chr($r) . chr($g) . chr($b) . chr($a);
			}
		}
		@imagedestroy($img);
		return $bytes;
	}
	
	public function onCommand(CommandSender $sender, Command $cmd, string $label, array $args) : bool{
		switch($cmd->getName()){
			case "pelerin":
			$items = [0 => Item::get(339)->setCustomName("Elmas Pelerin"), 1 => Item::get(339)->setCustomName("Golem Pelerin"), 2 => Item::get(339)->setCustomName("Geliştirici Pelerin"), 3 => Item::get(339)->setCustomName("Yaratık Pelerin"), 4 => Item::get(339)->setCustomName("OF Pelerin"), 5 => Item::get(339)->setCustomName("Enderman Pelerin"), 6 => Item::get(339)->setCustomName("İnci Pelerin"), 7 => Item::get(339)->setCustomName("Badlion Pelerin"), 8 => Item::get(339)->setCustomName("RKY Pelerin"), 9 => Item::get(339)->setCustomName("UHC Pelerin"), 10 => Item::get(339)->setCustomName("Lesg Pelerin"), 11 => Item::get(339)->setCustomName("Türk Pelerin"), 16 => Item::get(421)->setCustomName("§cPelerini Kaldır")];
			$menu = new ChestInventory();
			$menu->setContents($items);
			$menu->setName("Pelerin Ekranı");
			$menu->send($sender);
			break;
		}
		return true;
	}
	
	public function onClose(InventoryCloseEvent $e){
		// $e->setCancelled()
	}
	
	public function onClicked(InventoryClickEvent $e){
		$p = $e->getPlayer();
		$inv = $e->getInventory();
		$item = $e->getItem();
		switch($inv->getTitle()){
			case "Pelerin Ekranı":
			if($item->getCustomName() == "Elmas Pelerin"){
				$oldSkin = $p->getSkin();
				$capeData = $this->olusturPelerin("elmas");
				$setCape = new Skin($oldSkin->getSkinId(), $oldSkin->getSkinData(), $capeData, $oldSkin->getGeometryName(), $oldSkin->getGeometryData());
				$p->setSkin($setCape);
				$p->sendSkin();
				$p->sendMessage("§8[§c√§8] §7Elmas §aPelerini Başarıyla Takıldı!");
			}
			if($item->getCustomName() == "Golem Pelerin"){
				$oldSkin = $p->getSkin();
				$capeData = $this->olusturPelerin("golem");
				$setCape = new Skin($oldSkin->getSkinId(), $oldSkin->getSkinData(), $capeData, $oldSkin->getGeometryName(), $oldSkin->getGeometryData());
				$p->setSkin($setCape);
				$p->sendSkin();
				$p->sendMessage("§8[§c√§8] §7Golem §aPelerini Başarıyla Takıldı!");
               }
			if($item->getCustomName() == "Yaratık Pelerin"){
				$oldSkin = $p->getSkin();
				$capeData = $this->olusturPelerin("yaratik");
				$setCape = new Skin($oldSkin->getSkinId(), $oldSkin->getSkinData(), $capeData, $oldSkin->getGeometryName(), $oldSkin->getGeometryData());
				$p->setSkin($setCape);
				$p->sendSkin();
				$p->sendMessage("§8[§c√§8] §7Yaratık §aPelerini Başarıyla Takıldı!");
			}
						if($item->getCustomName() == "Geliştirici"){
				$oldSkin = $p->getSkin();
				$capeData = $this->olusturPelerin("developer");
				$setCape = new Skin($oldSkin->getSkinId(), $oldSkin->getSkinData(), $capeData, $oldSkin->getGeometryName(), $oldSkin->getGeometryData());
				$p->setSkin($setCape);
				$p->sendSkin();
				$p->sendMessage("§8[§c√§8] §7Geliştirici §aPelerini Başarıyla Takıldı!");
			}
			if($item->getCustomName() == "OF Pelerin"){
				$oldSkin = $p->getSkin();
				$capeData = $this->olusturPelerin("of");
				$setCape = new Skin($oldSkin->getSkinId(), $oldSkin->getSkinData(), $capeData, $oldSkin->getGeometryName(), $oldSkin->getGeometryData());
				$p->setSkin($setCape);
				$p->sendSkin();
				$p->sendMessage("§8[§c√§8] §7OF §aPelerini Başarıyla Takıldı!");
			}
			if($item->getCustomName() == "Enderman Pelerin"){
				$oldSkin = $p->getSkin();
				$capeData = $this->olusturPelerin("enderman");
				$setCape = new Skin($oldSkin->getSkinId(), $oldSkin->getSkinData(), $capeData, $oldSkin->getGeometryName(), $oldSkin->getGeometryData());
				$p->setSkin($setCape);
				$p->sendSkin();
				$p->sendMessage("§8[§c√§8] §7Enderman §aPelerini Başarıyla Takıldı!");
			}
			if($item->getCustomName() == "İnci Pelerin"){
				$oldSkin = $p->getSkin();
				$capeData = $this->olusturPelerin("inci");
				$setCape = new Skin($oldSkin->getSkinId(), $oldSkin->getSkinData(), $capeData, $oldSkin->getGeometryName(), $oldSkin->getGeometryData());
				$p->setSkin($setCape);
				$p->sendSkin();
				$p->sendMessage("§8[§c√§8] §7İnci §aPelerini Başarıyla Takıldı!");
			}
			if($item->getCustomName() == "Badlion Pelerin"){
				$oldSkin = $p->getSkin();
				$capeData = $this->olusturPelerin("badlion");
				$setCape = new Skin($oldSkin->getSkinId(), $oldSkin->getSkinData(), $capeData, $oldSkin->getGeometryName(), $oldSkin->getGeometryData());
				$p->setSkin($setCape);
				$p->sendSkin();
				$p->sendMessage("§8[§c√§8] §7Badlion §aPelerini Başarıyla Takıldı!");
			}
			if($item->getCustomName() == "RKY Pelerin"){
				$oldSkin = $p->getSkin();
				$capeData = $this->olusturPelerin("rky");
				$setCape = new Skin($oldSkin->getSkinId(), $oldSkin->getSkinData(), $capeData, $oldSkin->getGeometryName(), $oldSkin->getGeometryData());
				$p->setSkin($setCape);
				$p->sendSkin();
				$p->sendMessage("§8[§c√§8] §7RKY §aPelerini Başarıyla Takıldı!");
			}
			if($item->getCustomName() == "UHC Pelerin"){
				$oldSkin = $p->getSkin();
				$capeData = $this->olusturPelerin("uhc");
				$setCape = new Skin($oldSkin->getSkinId(), $oldSkin->getSkinData(), $capeData, $oldSkin->getGeometryName(), $oldSkin->getGeometryData());
				$p->setSkin($setCape);
				$p->sendSkin();
				$p->sendMessage("§8[§c√§8] §7UHC §aPelerini Başarıyla Takıldı!");
			}
			if($item->getCustomName() == "Lesg Pelerin"){
				$oldSkin = $p->getSkin();
				$capeData = $this->olusturPelerin("lesg");
				$setCape = new Skin($oldSkin->getSkinId(), $oldSkin->getSkinData(), $capeData, $oldSkin->getGeometryName(), $oldSkin->getGeometryData());
				$p->setSkin($setCape);
				$p->sendSkin();
				$p->sendMessage("§8[§c√§8] §7Lesg §aPelerini Başarıyla Takıldı!");
			}
			if($item->getCustomName() == "Türk Pelerin"){
				$oldSkin = $p->getSkin();
				$capeData = $this->olusturPelerin("turk");
				$setCape = new Skin($oldSkin->getSkinId(), $oldSkin->getSkinData(), $capeData, $oldSkin->getGeometryName(), $oldSkin->getGeometryData());
				$p->setSkin($setCape);
				$p->sendSkin();
				$p->sendMessage("§8[§c√§8] §7Türk §aPelerini Başarıyla Takıldı!");
			}
			if($item->getCustomName() == "§cPelerini Kaldır"){
				$oldSkin = $p->getSkin();
				$setCape = new Skin($oldSkin->getSkinId(), $oldSkin->getSkinData(), "", $oldSkin->getGeometryName(), $oldSkin->getGeometryData()); $p->setSkin($setCape);
				$p->sendSkin();
				$p->sendMessage("§aBaşarıyla Pelerin Kaldırıldı!");
			}
			break;
		}
	}
	
	public function SetSkin($player, string $file, string $ex, string $geo){
		$skin = $player->getSkin();
		$path = $this->getDataFolder() . $file . $ex;
		$img = @imagecreatefrompng($path);
		$skinbytes = "";
		$s = (int)@getimagesize($path)[1];

		for($y = 0; $y < $s; $y++){
			for($x = 0; $x < 64; $x++){
				$colorat = @imagecolorat($img, $x, $y);
				$a = ((~((int)($colorat >> 24))) << 1) & 0xff;
				$r = ($colorat >> 16) & 0xff;
				$g = ($colorat >> 8) & 0xff;
				$b = $colorat & 0xff;
				$skinbytes .= chr($r) . chr($g) . chr($b) . chr($a);
			}
		}
		@imagedestroy($img);
	}
}